import { useEffect, useState } from 'react';

type Ring = [number, number][];

// Decode quantized TopoJSON arcs into [lon, lat] polylines, without needing the
// topojson-client / world-atlas npm packages (which would add a build-time
// dependency + install step). Drawing every arc gives the full coastline.
function decodeTopology(topo: {
  arcs: number[][][];
  transform: { scale: [number, number]; translate: [number, number] };
}): Ring[] {
  const { scale, translate } = topo.transform;
  const rings: Ring[] = [];
  for (const arc of topo.arcs) {
    let x = 0;
    let y = 0;
    const line: Ring = [];
    for (const d of arc) {
      x += d[0];
      y += d[1];
      line.push([x * scale[0] + translate[0], y * scale[1] + translate[1]]);
    }
    rings.push(line);
  }
  return rings;
}

interface GlobeProps {
  isDark: boolean;
  lat: number | null;
  lon: number | null;
  size?: number;
  /** Spin only while visible; the sidebar stays mounted when hidden. */
  active?: boolean;
}

/**
 * Spinning orthographic globe with a real coastline world map (fetched once at
 * runtime) plus a graticule. No fill, so you see through to the back (drawn
 * fainter). Line color follows the theme. If the map can't be fetched (offline),
 * it shows just the graticule and keeps retrying in the background.
 */
export function Globe({ isDark, lat, lon, size = 360, active = true }: GlobeProps) {
  const [rot, setRot] = useState(0);
  const [landRings, setLandRings] = useState<Ring[]>([]);

  // Fetch the world coastline, retrying every 30 s until it succeeds (the app
  // may start before the network is up).
  useEffect(() => {
    let cancelled = false;
    let retry = 0;
    const sources = [
      'https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json',
      'https://unpkg.com/world-atlas@2/land-110m.json',
    ];
    const load = async () => {
      for (const url of sources) {
        try {
          const res = await fetch(url);
          if (!res.ok) continue;
          const topo = await res.json();
          if (cancelled) return;
          if (topo?.arcs && topo?.transform) {
            setLandRings(decodeTopology(topo));
            return;
          }
        } catch {
          /* try next source */
        }
      }
      if (!cancelled) retry = window.setTimeout(load, 30_000);
    };
    load();
    return () => {
      cancelled = true;
      clearTimeout(retry);
    };
  }, []);

  // Spin while active. dt is clamped so the globe doesn't lurch after the
  // window was hidden (rAF pauses) or run backwards on the first frame.
  useEffect(() => {
    if (!active) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(Math.max(now - last, 0), 100);
      last = now;
      setRot((r) => (r + dt * 0.012) % 360); // ~12°/s
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [active]);

  const R = size / 2 - 6;
  const cx = size / 2;
  const cy = size / 2;
  const tilt = (51 * Math.PI) / 180; // elevated, looking down on the North Pole
  const line = isDark ? '#faf9f5' : '#141413';
  const markerColor = '#3b82f6'; // location dot: blue regardless of theme

  const cosT = Math.cos(tilt);
  const sinT = Math.sin(tilt);
  // Rotate to view space: x right, y up, z toward the viewer (z >= 0 is front).
  const rotate = (latDeg: number, lonDeg: number) => {
    const phi = (latDeg * Math.PI) / 180;
    const lambda = ((lonDeg + rot) * Math.PI) / 180;
    const x = Math.cos(phi) * Math.sin(lambda);
    const y = Math.sin(phi);
    const z = Math.cos(phi) * Math.cos(lambda);
    return { x, y: y * cosT - z * sinT, z: y * sinT + z * cosT };
  };
  type V = ReturnType<typeof rotate>;
  const toScreen = (v: V) => `${(cx + v.x * R).toFixed(1)} ${(cy - v.y * R).toFixed(1)}`;
  const seg = (a: V, b: V) => `M${toScreen(a)}L${toScreen(b)}`;

  // Draw a polyline, splitting at the horizon so a segment that crosses the rim is
  // drawn half front, half back instead of popping between the two.
  const drawPolyline = (pts: V[], out: { front: string; back: string }) => {
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1];
      const b = pts[i];
      const aFront = a.z >= 0;
      const bFront = b.z >= 0;
      if (aFront === bFront) {
        if (aFront) out.front += seg(a, b);
        else out.back += seg(a, b);
        continue;
      }
      const t = a.z / (a.z - b.z);
      const mx = a.x + (b.x - a.x) * t;
      const my = a.y + (b.y - a.y) * t;
      const len = Math.hypot(mx, my) || 1;
      const m = { x: mx / len, y: my / len, z: 0 }; // snap onto the rim
      if (aFront) {
        out.front += seg(a, m);
        out.back += seg(m, b);
      } else {
        out.back += seg(a, m);
        out.front += seg(m, b);
      }
    }
  };

  const grid = { front: '', back: '' };
  // Full meridians: each loop draws one pole-to-pole half circle, so cover all
  // 360° of longitude (stopping at 180° left the far hemisphere without lines).
  for (let lon0 = 0; lon0 < 360; lon0 += 30) {
    const pts: V[] = [];
    for (let la = -90; la <= 90; la += 6) pts.push(rotate(la, lon0));
    drawPolyline(pts, grid);
  }
  for (const la0 of [-60, -30, 0, 30, 60]) {
    const pts: V[] = [];
    for (let lo = 0; lo <= 360; lo += 6) pts.push(rotate(la0, lo));
    drawPolyline(pts, grid);
  }

  const land = { front: '', back: '' };
  for (const ring of landRings) {
    drawPolyline(
      ring.map(([lo, la]) => rotate(la, lo)),
      land,
    );
  }

  const markerV = lat != null && lon != null ? rotate(lat, lon) : null;
  const marker = markerV ? { x: cx + markerV.x * R, y: cy - markerV.y * R, visible: markerV.z >= 0 } : null;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={cx} cy={cy} r={R} fill="none" stroke={line} strokeOpacity={0.22} strokeWidth={1} />
      <path d={grid.back} stroke={line} strokeOpacity={0.07} strokeWidth={0.6} fill="none" />
      <path d={land.back} stroke={line} strokeOpacity={0.14} strokeWidth={0.7} fill="none" />
      <path d={grid.front} stroke={line} strokeOpacity={0.22} strokeWidth={0.6} fill="none" />
      <path d={land.front} stroke={line} strokeOpacity={0.7} strokeWidth={0.9} fill="none" />
      {marker && (
        <g opacity={marker.visible ? 1 : 0.3}>
          <circle cx={marker.x} cy={marker.y} r={10} fill="none" stroke={markerColor} strokeOpacity={0.5}>
            <animate attributeName="r" from="5" to="15" dur="1.8s" repeatCount="indefinite" />
            <animate attributeName="stroke-opacity" from="0.6" to="0" dur="1.8s" repeatCount="indefinite" />
          </circle>
          <circle cx={marker.x} cy={marker.y} r={6} fill={markerColor} />
          <circle cx={marker.x} cy={marker.y} r={6} fill="none" stroke="#ffffff" strokeOpacity={0.85} strokeWidth={1} />
        </g>
      )}
    </svg>
  );
}
