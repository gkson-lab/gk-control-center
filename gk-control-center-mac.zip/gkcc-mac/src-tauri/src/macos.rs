// macOS data sources. These replace the PowerShell / CIM / netsh shell-outs used
// on Windows (and /proc on Linux) with the tools every Mac ships: `ioreg` for
// disk and GPU counters, `ps` for process/thread counts, sysinfo's IOKit sensors
// for temperatures, and `route`, `ipconfig`, `scutil` and `system_profiler` for
// the network sidebar. None of them need admin rights, and every source degrades
// gracefully: a missing value just leaves that field empty.
//
// Not available without root on macOS: system-wide context switches and system
// calls per second. Those show N/A in the UI.

use super::{PsGpu, PsStats, POLL_INTERVAL_MS};
use std::collections::HashMap;
use std::process::Command;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};
use sysinfo::Components;

// `ps -A -M` costs ~0.1 s of CPU, so refresh process/thread counts every few
// polls instead of every second.
const PS_EVERY_N_POLLS: u64 = 3;

// ---------- Small helpers ----------

fn run(cmd: &str, args: &[&str]) -> Option<String> {
    let output = Command::new(cmd).args(args).output().ok()?;
    if output.status.success() {
        Some(String::from_utf8_lossy(&output.stdout).into_owned())
    } else {
        None
    }
}

/// Parses the numeric entries of an ioreg dictionary line such as
/// `"Statistics" = {"Operations (Read)"=12,"Bytes (Read)"=4096}`.
/// Non-numeric values are skipped.
fn parse_ioreg_dict(line: &str) -> HashMap<String, f64> {
    let mut out = HashMap::new();
    let Some(start) = line.find("= {") else { return out };
    let body = line[start + 3..].trim_end().trim_end_matches('}');
    for entry in body.split(',') {
        let Some((k, v)) = entry.split_once('=') else { continue };
        if let Ok(n) = v.trim().parse::<f64>() {
            out.insert(k.trim().trim_matches('"').to_string(), n);
        }
    }
    out
}

/// `"model" = "Apple M4"` or `"model" = <"AMD Radeon Pro 5500M">` → the name.
fn parse_ioreg_string(line: &str) -> Option<String> {
    let (_, v) = line.split_once(" = ")?;
    let s = v.trim().trim_start_matches('<').trim_end_matches('>').trim_matches('"');
    (!s.is_empty()).then(|| s.trim_end_matches('\0').to_string())
}

/// The `<class Name, ...>` part of an ioreg `+-o` line.
fn ioreg_class(line: &str) -> &str {
    line.split_once("<class ")
        .and_then(|(_, rest)| rest.split([',', '>']).next())
        .unwrap_or("")
}

// ---------- Disk I/O (ioreg IOBlockStorageDriver statistics) ----------

#[derive(Clone, Copy, Default, Debug, PartialEq)]
struct DiskCounters {
    reads: f64,
    writes: f64,
    read_bytes: f64,
    write_bytes: f64,
    busy_ns: f64,
}

/// Cumulative counters per physical disk. Mounted disk images are skipped so
/// reading a .dmg isn't counted twice (once for the image, once for the SSD).
fn parse_disk_stats(text: &str) -> HashMap<String, DiskCounters> {
    let mut out = HashMap::new();
    let mut device: Option<String> = None;
    for line in text.lines() {
        if line.starts_with("+-o ") {
            let class = ioreg_class(line);
            device = (!class.contains("DiskImage")).then(|| line[4..].split("  <").next().unwrap_or("").to_string());
        } else if line.contains("\"Statistics\" = {") {
            let Some(name) = &device else { continue };
            let s = parse_ioreg_dict(line);
            let g = |k: &str| s.get(k).copied().unwrap_or(0.0);
            out.insert(
                name.clone(),
                DiskCounters {
                    reads: g("Operations (Read)"),
                    writes: g("Operations (Write)"),
                    read_bytes: g("Bytes (Read)"),
                    write_bytes: g("Bytes (Write)"),
                    busy_ns: g("Total Time (Read)") + g("Total Time (Write)"),
                },
            );
        }
    }
    out
}

fn read_disk_stats() -> HashMap<String, DiskCounters> {
    run("ioreg", &["-r", "-c", "IOBlockStorageDevice", "-d", "2", "-l", "-w0"])
        .map(|t| parse_disk_stats(&t))
        .unwrap_or_default()
}

// ---------- Processes / threads (ps) ----------

/// `ps -A -M` prints a header, then one line per thread; the first thread of
/// each process carries the user name in column 1, later ones start with spaces.
/// Returns (processes, threads).
fn parse_ps_threads(text: &str) -> (u32, u32) {
    let mut procs = 0;
    let mut threads = 0;
    for line in text.lines().skip(1).filter(|l| !l.trim().is_empty()) {
        threads += 1;
        if !line.starts_with(char::is_whitespace) {
            procs += 1;
        }
    }
    (procs, threads)
}

// ---------- GPU (ioreg IOAccelerator) ----------

#[derive(Default, Debug, PartialEq)]
struct AccelStats {
    name: String,
    usage: f64,
    mem_used_mb: f64,
    mem_total_mb: f64,
}

/// One entry per GPU. Apple Silicon reports "Device Utilization %" and "In use
/// system memory" (unified memory, so the total is the Mac's RAM); AMD/Intel
/// GPUs on Intel Macs report VRAM used/free.
fn parse_accelerators(text: &str, ram_mb: f64) -> Vec<AccelStats> {
    let mut out: Vec<AccelStats> = Vec::new();
    for line in text.lines() {
        if line.starts_with("+-o ") {
            out.push(AccelStats::default());
            continue;
        }
        let Some(cur) = out.last_mut() else { continue };
        let t = line.trim_start_matches(|c: char| c == ' ' || c == '|');
        if t.starts_with("\"model\" = ") {
            if let Some(n) = parse_ioreg_string(t) {
                cur.name = n;
            }
        } else if t.starts_with("\"PerformanceStatistics\" = {") {
            let s = parse_ioreg_dict(t);
            cur.usage = s
                .get("Device Utilization %")
                .or_else(|| s.get("GPU Activity(%)"))
                .copied()
                .unwrap_or(0.0);
            if let Some(used) = s.get("In use system memory") {
                cur.mem_used_mb = used / 1_048_576.0;
                cur.mem_total_mb = ram_mb;
            } else if let (Some(used), Some(free)) = (s.get("vramUsedBytes"), s.get("vramFreeBytes")) {
                cur.mem_used_mb = used / 1_048_576.0;
                cur.mem_total_mb = (used + free) / 1_048_576.0;
            }
        }
    }
    out.retain(|g| !g.name.is_empty());
    out
}

// ---------- Temperatures (IOKit sensors via sysinfo) ----------

/// Hottest sensor whose label matches one of `pats` (case-insensitive), trying
/// each group in order. Apple Silicon labels look like "PMU tdie3",
/// "pACC MTR Temp Sensor2", "GPU MTR Temp Sensor1"; Intel Macs expose SMC
/// sensors such as "CPU Proximity".
fn pick_temp<'a>(sensors: impl Iterator<Item = (&'a str, f32)> + Clone, groups: &[&[&str]]) -> Option<f64> {
    let valid = |t: f32| t.is_finite() && t > 0.0 && t < 150.0;
    groups.iter().find_map(|pats| {
        sensors
            .clone()
            .filter(|(label, t)| {
                let l = label.to_ascii_lowercase();
                valid(*t) && pats.iter().any(|p| l.contains(p))
            })
            .map(|(_, t)| t as f64)
            .fold(None, |m: Option<f64>, t| Some(m.map_or(t, |m| m.max(t))))
    })
}

const CPU_SENSORS: &[&[&str]] = &[&["tdie"], &["pacc", "eacc", "cpu"]];
const GPU_SENSORS: &[&[&str]] = &[&["gpu"]];

// ---------- Poller ----------

pub(crate) fn poller_loop(shared: Arc<Mutex<PsStats>>) {
    let mut components = Components::new_with_refreshed_list();
    let ram_mb = run("sysctl", &["-n", "hw.memsize"])
        .and_then(|s| s.trim().parse::<f64>().ok())
        .unwrap_or(0.0)
        / 1_048_576.0;
    let mut prev_disks: Option<HashMap<String, DiskCounters>> = None;
    let mut prev_time = Instant::now();
    let mut counts = (0u32, 0u32);
    let mut poll: u64 = 0;

    loop {
        let now = Instant::now();
        let secs = now.duration_since(prev_time).as_secs_f64().max(1e-3);
        prev_time = now;

        let mut stats = PsStats::default();

        // Disk I/O rates from counter deltas.
        let disks = read_disk_stats();
        if let Some(prev) = &prev_disks {
            let mut max_busy = 0.0f64;
            for (name, cur) in &disks {
                let Some(old) = prev.get(name) else { continue };
                let d = |a: f64, b: f64| (a - b).max(0.0);
                stats.reads += d(cur.reads, old.reads) / secs;
                stats.writes += d(cur.writes, old.writes) / secs;
                stats.read_bytes += d(cur.read_bytes, old.read_bytes) / secs;
                stats.write_bytes += d(cur.write_bytes, old.write_bytes) / secs;
                let busy = d(cur.busy_ns, old.busy_ns) / (secs * 1e9) * 100.0;
                max_busy = max_busy.max(busy);
            }
            stats.busy = max_busy.min(100.0);
        }
        prev_disks = Some(disks);

        if poll % PS_EVERY_N_POLLS == 0 {
            if let Some(t) = run("ps", &["-A", "-M"]) {
                counts = parse_ps_threads(&t);
            }
        }
        poll = poll.wrapping_add(1);
        (stats.processes, stats.threads) = counts;

        components.refresh();
        let sensors = components.list().iter().map(|c| (c.label(), c.temperature()));
        stats.cpu_temp = pick_temp(sensors.clone(), CPU_SENSORS);
        let gpu_temp = pick_temp(sensors, GPU_SENSORS);

        let gpus = run("ioreg", &["-r", "-d", "1", "-w0", "-c", "IOAccelerator"])
            .map(|t| parse_accelerators(&t, ram_mb))
            .unwrap_or_default();
        // With two GPUs (older MacBook Pros), show the busier one.
        stats.gpu = gpus
            .into_iter()
            .max_by(|a, b| a.usage.total_cmp(&b.usage))
            .map(|g| PsGpu {
                name: g.name,
                usage: g.usage,
                temp: gpu_temp.unwrap_or(0.0),
                mem_used: g.mem_used_mb,
                mem_total: g.mem_total_mb,
                ..PsGpu::default()
            });

        if let Ok(mut guard) = shared.lock() {
            *guard = stats;
        }
        thread::sleep(Duration::from_millis(POLL_INTERVAL_MS));
    }
}

// ---------- Network info (sidebar) ----------

/// `route -n get default` → (gateway, interface)
fn parse_route(text: &str) -> (Option<String>, Option<String>) {
    let field = |key: &str| {
        text.lines()
            .find_map(|l| l.trim().strip_prefix(key))
            .map(|v| v.trim().to_string())
            .filter(|v| !v.is_empty())
    };
    (field("gateway:"), field("interface:"))
}

/// Unique nameservers from `scutil --dns`, in order.
fn parse_scutil_dns(text: &str) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    for l in text.lines() {
        let l = l.trim();
        if !l.starts_with("nameserver[") {
            continue;
        }
        if let Some((_, v)) = l.split_once(':') {
            let v = v.trim().to_string();
            if !v.is_empty() && !out.contains(&v) {
                out.push(v);
            }
        }
    }
    out
}

/// Device name of the Wi-Fi port from `networksetup -listallhardwareports`.
fn parse_wifi_device(text: &str) -> Option<String> {
    let mut lines = text.lines();
    while let Some(l) = lines.next() {
        if l.starts_with("Hardware Port:") && (l.contains("Wi-Fi") || l.contains("AirPort")) {
            return lines.next()?.strip_prefix("Device:").map(|d| d.trim().to_string());
        }
    }
    None
}

#[derive(Default, Debug, PartialEq)]
struct WifiLink {
    ssid: Option<String>,
    signal: Option<i64>,
    radio: Option<String>,
    band: Option<String>,
    channel: Option<String>,
    tx: Option<String>,
    auth: Option<String>,
}

/// "spairport_security_mode_wpa2_personal" → "WPA2 Personal"
fn pretty_security(mode: &str) -> String {
    mode.trim_start_matches("spairport_security_mode_")
        .split('_')
        .map(|w| {
            if w.starts_with("wpa") || w == "wep" {
                w.to_uppercase()
            } else {
                let mut c = w.chars();
                c.next().map(|f| f.to_uppercase().collect::<String>() + c.as_str()).unwrap_or_default()
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

/// Current network of `iface` from `system_profiler -json SPAirPortDataType`.
/// macOS hides the network name from apps without Location access, so a
/// "<redacted>" name is shown as a neutral placeholder.
fn parse_airport_json(text: &str, iface: &str) -> WifiLink {
    let mut w = WifiLink::default();
    let Ok(v) = serde_json::from_str::<serde_json::Value>(text) else { return w };
    let interfaces = v["SPAirPortDataType"]
        .as_array()
        .into_iter()
        .flatten()
        .flat_map(|b| b["spairport_airport_interfaces"].as_array().into_iter().flatten());
    let Some(net) = interfaces
        .filter(|i| i["_name"].as_str() == Some(iface))
        .map(|i| &i["spairport_current_network_information"])
        .find(|n| n.is_object() && n.get("spairport_network_channel").is_some())
    else {
        return w;
    };
    let s = |k: &str| net[k].as_str().map(|x| x.to_string());

    w.ssid = s("_name").map(|n| if n.starts_with('<') { "Connected (name hidden by macOS)".into() } else { n });
    if let Some(sn) = s("spairport_signal_noise") {
        let dbm: i64 = sn.split_whitespace().next().and_then(|x| x.parse().ok()).unwrap_or(-100);
        w.signal = Some((2 * (dbm + 100)).clamp(0, 100));
    }
    w.radio = s("spairport_network_phymode");
    if let Some(ch) = s("spairport_network_channel") {
        // "149 (5GHz, 80MHz)"
        w.channel = ch.split_whitespace().next().map(|x| x.to_string());
        w.band = ch
            .split_once('(')
            .and_then(|(_, r)| r.split([',', ')']).next())
            .map(|b| b.trim().replace("GHz", " GHz"));
    }
    w.tx = net["spairport_network_rate"].as_f64().map(|r| format!("{}", r));
    w.auth = s("spairport_security_mode").map(|m| pretty_security(&m));
    w
}

pub(crate) fn network_info() -> serde_json::Value {
    let (gateway, iface) = run("route", &["-n", "get", "default"])
        .map(|t| parse_route(&t))
        .unwrap_or((None, None));
    let dns = run("scutil", &["--dns"]).map(|t| parse_scutil_dns(&t)).unwrap_or_default();

    let mut local_v4 = None;
    let mut wifi = WifiLink::default();
    if let Some(dev) = iface.as_deref() {
        local_v4 = run("ipconfig", &["getifaddr", dev]).map(|s| s.trim().to_string()).filter(|s| !s.is_empty());
        let wifi_dev = run("networksetup", &["-listallhardwareports"]).and_then(|t| parse_wifi_device(&t));
        if wifi_dev.as_deref() == Some(dev) {
            // Slow (several seconds): it also scans for nearby networks. This
            // command runs off the UI thread, so the sidebar stays responsive.
            wifi = run("system_profiler", &["-json", "SPAirPortDataType"])
                .map(|t| parse_airport_json(&t, dev))
                .unwrap_or_default();
        }
    }

    serde_json::json!({
        "iface": iface, "gateway": gateway, "localV4": local_v4, "dns": dns,
        "ssid": wifi.ssid, "bssid": null, "signal": wifi.signal, "radio": wifi.radio,
        "band": wifi.band, "channel": wifi.channel, "rxMbps": null, "txMbps": wifi.tx,
        "auth": wifi.auth,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Prints what this Mac's real data sources return:
    /// `cargo test --lib live_probe -- --ignored --nocapture`
    #[test]
    #[ignore]
    fn live_probe() {
        let mut c = Components::new_with_refreshed_list();
        c.refresh();
        let sensors: Vec<(String, f32)> = c.list().iter().map(|x| (x.label().to_string(), x.temperature())).collect();
        println!("sensors: {:?}", sensors);
        let it = sensors.iter().map(|(l, t)| (l.as_str(), *t));
        println!("cpu temp {:?}, gpu temp {:?}", pick_temp(it.clone(), CPU_SENSORS), pick_temp(it, GPU_SENSORS));
        println!("disks: {:?}", read_disk_stats());
        println!("procs/threads: {:?}", run("ps", &["-A", "-M"]).map(|t| parse_ps_threads(&t)));
        println!(
            "gpus: {:?}",
            run("ioreg", &["-r", "-d", "1", "-w0", "-c", "IOAccelerator"]).map(|t| parse_accelerators(&t, 16384.0))
        );
        println!("network: {}", network_info());
    }

    #[test]
    fn disk_stats_skip_disk_images() {
        let text = "+-o NS_01@1  <class IOEmbeddedNVMeBlockDevice, id 0x1, registered>\n\
                    \x20 | {\n\
                    \x20 +-o IOBlockStorageDriver  <class IOBlockStorageDriver, id 0x2>\n\
                    \x20     \"Statistics\" = {\"Operations (Write)\"=50,\"Bytes (Read)\"=4096,\"Total Time (Read)\"=1000,\"Bytes (Write)\"=8192,\"Operations (Read)\"=100,\"Total Time (Write)\"=500}\n\
                    +-o AppleDiskImageDevice@0  <class AppleDiskImageDevice, id 0x3>\n\
                    \x20 +-o IOBlockStorageDriver  <class IOBlockStorageDriver, id 0x4>\n\
                    \x20     \"Statistics\" = {\"Operations (Write)\"=9,\"Bytes (Read)\"=9,\"Operations (Read)\"=9}\n";
        let d = parse_disk_stats(text);
        assert_eq!(d.len(), 1);
        assert_eq!(
            d["NS_01@1"],
            DiskCounters { reads: 100.0, writes: 50.0, read_bytes: 4096.0, write_bytes: 8192.0, busy_ns: 1500.0 }
        );
    }

    #[test]
    fn ps_thread_counts() {
        let text = "USER PID TT %CPU STAT PRI STIME UTIME COMMAND\n\
                    root 1 ?? 0.0 S 31T 0:00.32 0:00.07 /sbin/launchd\n\
                    \x20    1    0.0 S 20T 0:00.01 0:00.02\n\
                    me 99 ?? 0.0 S 31T 0:00.01 0:00.01 /bin/zsh\n";
        assert_eq!(parse_ps_threads(text), (2, 3));
    }

    #[test]
    fn accelerator_stats() {
        let text = "+-o AGXAcceleratorG16G  <class AGXAcceleratorG16G, id 0x1>\n\
                    \x20   \"PerformanceStatistics\" = {\"Device Utilization %\"=44,\"In use system memory\"=1048576000,\"Alloc system memory\"=2491416576}\n\
                    \x20   \"model\" = \"Apple M4\"\n";
        let g = parse_accelerators(text, 16384.0);
        assert_eq!(g, vec![AccelStats { name: "Apple M4".into(), usage: 44.0, mem_used_mb: 1000.0, mem_total_mb: 16384.0 }]);
        let amd = "+-o AMDRadeonX6000_AMDNavi14GraphicsAccelerator  <class X, id 0x2>\n\
                   \x20   \"model\" = <\"AMD Radeon Pro 5500M\">\n\
                   \x20   \"PerformanceStatistics\" = {\"vramUsedBytes\"=1048576,\"vramFreeBytes\"=3145728,\"Device Utilization %\"=7}\n";
        let g = parse_accelerators(amd, 0.0);
        assert_eq!((g[0].name.as_str(), g[0].usage, g[0].mem_total_mb), ("AMD Radeon Pro 5500M", 7.0, 4.0));
    }

    #[test]
    fn temps() {
        let s = vec![("PMU tdie1", 41.0), ("PMU tdie3", 47.5), ("GPU MTR Temp Sensor1", 39.0), ("NAND CH0 temp", 30.0)];
        assert_eq!(pick_temp(s.iter().map(|(l, t)| (*l, *t)), CPU_SENSORS), Some(47.5));
        assert_eq!(pick_temp(s.iter().map(|(l, t)| (*l, *t)), GPU_SENSORS), Some(39.0));
        let s = vec![("pACC MTR Temp Sensor2", 52.0), ("eACC MTR Temp Sensor0", 44.0)];
        assert_eq!(pick_temp(s.iter().map(|(l, t)| (*l, *t)), CPU_SENSORS), Some(52.0));
        assert_eq!(pick_temp(std::iter::empty(), CPU_SENSORS), None);
    }

    #[test]
    fn network_parsers() {
        let route = "   route to: default\ndestination: default\n    gateway: 192.168.86.1\n  interface: en0\n";
        assert_eq!(parse_route(route), (Some("192.168.86.1".into()), Some("en0".into())));
        let dns = "resolver #1\n  nameserver[0] : 192.168.86.1\n  nameserver[1] : 1.1.1.1\nresolver #2\n  nameserver[0] : 192.168.86.1\n";
        assert_eq!(parse_scutil_dns(dns), vec!["192.168.86.1", "1.1.1.1"]);
        let ports = "Hardware Port: Ethernet\nDevice: en1\nEthernet Address: x\n\nHardware Port: Wi-Fi\nDevice: en0\n";
        assert_eq!(parse_wifi_device(ports).as_deref(), Some("en0"));
        assert_eq!(pretty_security("spairport_security_mode_wpa2_personal"), "WPA2 Personal");
    }

    #[test]
    fn airport_json() {
        let j = r#"{"SPAirPortDataType":[{"spairport_airport_interfaces":[
            {"_name":"en0","spairport_current_network_information":{"_name":"<redacted>",
              "spairport_network_channel":"149 (5GHz, 80MHz)","spairport_network_phymode":"802.11ac",
              "spairport_network_rate":6,"spairport_security_mode":"spairport_security_mode_wpa2_personal",
              "spairport_signal_noise":"-54 dBm / -92 dBm"}},
            {"_name":"awdl0","spairport_current_network_information":{"spairport_network_type":"x"}}]}]}"#;
        let w = parse_airport_json(j, "en0");
        assert_eq!(w.ssid.as_deref(), Some("Connected (name hidden by macOS)"));
        assert_eq!(w.signal, Some(92));
        assert_eq!((w.band.as_deref(), w.channel.as_deref()), (Some("5 GHz"), Some("149")));
        assert_eq!((w.radio.as_deref(), w.tx.as_deref(), w.auth.as_deref()), (Some("802.11ac"), Some("6"), Some("WPA2 Personal")));
        assert_eq!(parse_airport_json(j, "en1"), WifiLink::default());
    }
}
