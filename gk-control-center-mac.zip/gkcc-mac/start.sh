#!/usr/bin/env bash
# ---------------------------------------------------------------------------
#  One-step launcher for GK Control Center on macOS (the start.bat / Linux
#  start.sh equivalent). Run it from Terminal with:   bash start.sh
#  (or double-click "Start GK Control Center.command").
#
#  On first run it offers to install what's missing — Apple's Command Line
#  Tools, Node.js and Rust (no admin password needed for the last two) — then
#  builds a real "GK Control Center.app" and opens it. The first build takes a
#  few minutes; after that it opens in seconds, and you can launch the app
#  from Applications / Spotlight / Launchpad like any other.
# ---------------------------------------------------------------------------
set -u
cd "$(dirname "$0")" || exit 1

NODE_VERSION="v24.21.0"   # Node.js LTS, installed to ~/.local/node if needed
APP_NAME="GK Control Center"
APP="src-tauri/target/release/bundle/macos/$APP_NAME.app"

fail() {
  echo
  echo "[!] $1"
  [ -t 0 ] && read -r -p "Press Enter to close..." _
  exit 1
}

ask() {
  read -r -p "$1 [Y/n] " answer
  case "${answer:-Y}" in [Yy]*) return 0 ;; *) return 1 ;; esac
}

have() { command -v "$1" >/dev/null 2>&1; }

# A ':' in the folder path breaks the build: PATH uses ':' as its separator, so
# the build tools inside node_modules/.bin can't be found. (Finder shows ':' as
# '/', so a folder that looks like "cursor/projects" may really be "cursor:projects".)
case "$PWD" in
  *:*) fail "This folder's path contains a ':' character, which breaks the build:
    $PWD
Move the gkcc-mac folder somewhere without ':' in its path (your home folder or
Documents is fine) and run start.sh again." ;;
esac

[ "$(uname -s)" = "Darwin" ] || fail "This is the macOS edition. Use the Linux or Windows package on other systems."

# Tools installed by a previous run (or by rustup) that may not be on PATH yet.
[ -d "$HOME/.local/node/bin" ] && export PATH="$HOME/.local/node/bin:$PATH"
[ -f "$HOME/.cargo/env" ] && . "$HOME/.cargo/env"

# ---- Apple Command Line Tools (compiler, linker) ----
if ! xcode-select -p >/dev/null 2>&1; then
  echo "Apple's Command Line Tools aren't installed yet (they provide the compiler)."
  echo "A macOS window will open to install them. When it finishes, run this again."
  xcode-select --install 2>/dev/null
  fail "Waiting for the Command Line Tools install."
fi

# ---- Node.js 20+ ----
node_ok() {
  have node && have npm || return 1
  local major
  major=$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)
  [ "$major" -ge 20 ] 2>/dev/null
}

if ! node_ok; then
  if have node; then
    echo "Node.js $(node -v) is too old; version 20 or newer is needed."
  else
    echo "Node.js isn't installed yet (it builds the app's interface)."
  fi
  case "$(uname -m)" in arm64) arch=arm64 ;; *) arch=x64 ;; esac
  pkg="node-$NODE_VERSION-darwin-$arch"
  ask "Install Node.js $NODE_VERSION into ~/.local/node (from nodejs.org, no admin needed)?" \
    || fail "Can't start without Node.js. You can also install it from https://nodejs.org"
  mkdir -p "$HOME/.local" || fail "Couldn't create ~/.local"
  tmp=$(mktemp -d) || fail "Couldn't create a temp folder."
  echo "Downloading $pkg..."
  curl -fsSL "https://nodejs.org/dist/$NODE_VERSION/$pkg.tar.gz" -o "$tmp/$pkg.tar.gz" \
    || fail "Downloading Node.js failed. Check your internet connection."
  sum=$(curl -fsSL "https://nodejs.org/dist/$NODE_VERSION/SHASUMS256.txt" | grep " $pkg.tar.gz\$" | awk '{print $1}')
  got=$(shasum -a 256 "$tmp/$pkg.tar.gz" | awk '{print $1}')
  [ -n "$sum" ] && [ "$sum" = "$got" ] || fail "The Node.js download didn't match its checksum; not installing it."
  tar -xzf "$tmp/$pkg.tar.gz" -C "$HOME/.local" || fail "Unpacking Node.js failed."
  ln -sfn "$pkg" "$HOME/.local/node"
  rm -rf "$tmp"
  export PATH="$HOME/.local/node/bin:$PATH"
  node_ok || fail "Node.js still isn't working. Install the LTS from https://nodejs.org and run this again."
fi

# ---- Rust (via rustup, no admin needed) ----
if ! have cargo; then
  echo "Rust isn't installed yet (it compiles the app's backend)."
  ask "Install it now with rustup (https://rustup.rs)?" || fail "Can't start without Rust."
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal \
    || fail "Installing Rust failed."
  . "$HOME/.cargo/env"
fi

# ---- JS dependencies ----
# Also reinstall if node_modules came from another OS (its native tools won't run here).
if [ ! -d node_modules ] || ! ls -d node_modules/@tauri-apps/cli-darwin-* >/dev/null 2>&1; then
  echo "Installing dependencies (first run only)..."
  rm -rf node_modules
  npm install --no-audit --no-fund || fail "npm install failed. Try: bash clean.sh, then bash start.sh"
fi

# ---- Build the .app (only when it's missing or the source changed) ----
stale=1
if [ -d "$APP" ]; then
  stale=0
  [ -n "$(find src src-tauri/src src-tauri/Cargo.toml src-tauri/tauri.conf.json index.html package.json \
          -newer "$APP" -print -quit 2>/dev/null)" ] && stale=1
fi
if [ $stale = 1 ]; then
  echo "Building $APP_NAME.app (the first build takes a few minutes)..."
  npm run tauri build -- --bundles app || fail "The build failed. Scroll up for the error."
  touch "$APP"
fi

# ---- Offer to add it to Applications, then open it ----
dest="$HOME/Applications/$APP_NAME.app"
if [ -t 0 ] && { [ ! -d "$dest" ] || [ "$APP" -nt "$dest" ]; }; then
  if ask "Add $APP_NAME to your Applications folder (~/Applications) so you can open it from Spotlight?"; then
    mkdir -p "$HOME/Applications"
    rm -rf "$dest"
    ditto "$APP" "$dest" && echo "Added: $dest"
  fi
fi
[ -d "$dest" ] && [ ! "$APP" -nt "$dest" ] && APP="$dest"

echo "Opening $APP_NAME..."
open "$APP" || fail "Couldn't open $APP"
