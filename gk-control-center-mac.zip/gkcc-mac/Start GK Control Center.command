#!/usr/bin/env bash
# Double-click to build (first time) and open GK Control Center.
# The first time, macOS may block it: right-click this file > Open > Open.
cd "$(dirname "$0")" && bash start.sh
