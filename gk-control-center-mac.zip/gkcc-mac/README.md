# GK Control Center — macOS

A sleek, real-time system monitor: live CPU / memory / GPU gauges, per-core
processor bars, Apple GPU telemetry, disk IOPS and throughput, network speed,
process and thread counts, a runtime odometer, and a spinning globe that shows
where your connection is.

Built with Tauri 2 + React. This package is the macOS edition (Apple Silicon
and Intel Macs, macOS 11 Big Sur or newer).

## Quick start

1. Double-click the zip to unzip it, and move the `gkcc-mac` folder somewhere
   handy (your home folder or Documents).
2. Open **Terminal**, type `bash ` (with a space), drag `start.sh` from the
   `gkcc-mac` folder onto the Terminal window, and press Return.

   Or double-click **Start GK Control Center.command**. The first time, macOS
   may say it can't verify the developer: right-click the file, choose
   **Open**, then **Open** again.

That's it. `start.sh` takes care of everything:

1. **Installs what's missing** (first run only): Apple's Command Line Tools
   (a macOS window pops up for these), Node.js and Rust. It asks before each
   one; Node.js and Rust install into your user folder, no admin password.
2. **Downloads the app's dependencies** (first run only).
3. **Builds `GK Control Center.app` and opens it.** The first build takes a
   few minutes. It then offers to add the app to your Applications folder
   (`~/Applications`), so from then on you can open it from Spotlight or
   Launchpad like any other app; no Terminal needed.

Running `bash start.sh` again only rebuilds if the source changed, so it opens
in seconds.

> **Keep the folder path free of `:`.** Finder shows a `:` in a folder name as
> `/`, so a folder that looks like `cursor/projects` may really be
> `cursor:projects`. The build tools can't run from such a path, and
> `start.sh` will tell you if that's the case.

## What you'll see, and where it comes from

| Reading | Source | Notes |
| --- | --- | --- |
| CPU load, per-core bars, frequency, memory, swap, storage, network speed | `sysinfo` | Works everywhere |
| Disk IOPS, MB/s, active time | `ioreg` (IOBlockStorageDriver statistics) | Physical disks only; mounted disk images are skipped so nothing is counted twice |
| Processes, threads | `ps` | Refreshed every few seconds |
| Context switches/s, syscalls/s | — | macOS has no system-wide counter without admin rights, so these show **N/A** |
| CPU and GPU temperature | IOKit sensors | Apple Silicon and Intel; shows N/A if the Mac doesn't expose them |
| GPU card | `ioreg` (IOAccelerator) | Apple GPUs show usage and shared memory. Macs don't report GPU power, clocks or fan, so those are hidden |
| Wi-Fi, router, DNS (Location panel) | `system_profiler`, `route`, `ipconfig`, `scutil` | Wi-Fi details take a few seconds to read. macOS hides the network *name* from apps, so it shows "name hidden by macOS" |
| Public IP, ISP, globe location | ipapi.co (ipwho.is as a backup), ipify | Needs an internet connection |

## Troubleshooting

**"Command Line Tools" window, then the script stops.**
Expected on a brand-new Mac: finish the install in that window, then run
`bash start.sh` again.

**macOS says the app or `.command` file "can't be opened".**
Right-click it, choose **Open**, then **Open**. Apps you build yourself with
`start.sh` normally open without this prompt.

**`npm install failed`.**
Delete the downloaded dependencies and try again:

```bash
bash clean.sh
bash start.sh
```

**The build fails right away with "command not found" errors.**
Check the folder path for a `:` (see the note in Quick start).

## Freeing up disk space

The folder grows to a few GB after the first build. That's build cache, not
the app. Run `bash clean.sh` to delete it. A copy in `~/Applications` keeps
working; the next `bash start.sh` rebuilds the cache.

## Uninstalling

Delete the `gkcc-mac` folder and `~/Applications/GK Control Center.app`, plus
`~/Library/Application Support/com.gkcc.controlcenter`,
`~/Library/Caches/com.gkcc.controlcenter` and
`~/Library/WebKit/com.gkcc.controlcenter` (the app's odometer file and web
cache, a few MB at most). If start.sh installed them for you, remove Node.js
with `rm -rf ~/.local/node ~/.local/node-v*` and Rust with
`rustup self uninstall`.

## Files

```
gkcc-mac/
├── start.sh                         one-step setup + build + open
├── Start GK Control Center.command  double-click version of start.sh
├── clean.sh                         delete build caches
├── src/                             the interface (React + TypeScript)
└── src-tauri/                       the backend (Rust)
    └── src/macos.rs                 the macOS data sources
```

---

made with ♥ by gkson
